package com.library.management.system.service;

import com.library.management.system.dto.Books;

public interface BookLibrary {
	Books getBookName(int bookid);

}
