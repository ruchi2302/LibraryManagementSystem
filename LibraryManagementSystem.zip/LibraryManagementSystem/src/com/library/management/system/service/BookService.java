package com.library.management.system.service;

public interface BookService {
	public void search(int bookId);
}
