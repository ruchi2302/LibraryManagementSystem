package com.libraray.management.system.controller;

public class Test {
	public static void main(String[] args) {
		BookFactoryController.startFactory();
	}

}
